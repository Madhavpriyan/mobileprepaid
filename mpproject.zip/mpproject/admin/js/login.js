document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Simple validation (in a real app, this would be a server request)
    if (username === 'admin' && password === 'admin123') {
      // Set session flag
      sessionStorage.setItem('loggedIn', 'true');
      // Redirect to dashboard
      window.location.href = 'dashboard.html';
    } else {
      document.getElementById('loginError').style.display = 'block';
    }
  });